# Kasir Nominal — Android (versi 3)

Aplikasi kasir nominal sederhana untuk Android. Transaksi disimpan di database SQLite lokal pada HP dan aplikasi dapat dipakai offline setelah terpasang.

## Fitur pada versi ini
- Tombol angka 0–9, 00, dan 000.
- Tombol tambah (+), pengurang (−), hapus satu digit (⌫), dan hapus input (C).
- Tombol `= HITUNG SUBTOTAL` untuk memasukkan nominal yang sedang diketik ke daftar dan menampilkan subtotal.
- Daftar nominal masuk dan pengurang.
- Simpan transaksi ke SQLite lokal.
- Laporan omzet harian.
- Cetak struk/laporan ke printer Bluetooth Classic SPP yang mendukung ESC/POS (termasuk sebagian printer thermal 58 mm).
- Ekspor cadangan transaksi dalam format CSV ke folder khusus aplikasi.

## Build APK melalui GitHub Actions
1. Unggah isi proyek ini ke root repositori GitHub (folder `app`, `.github`, `build.gradle`, `settings.gradle`, dan file lainnya).
2. Buka tab **Actions** dan izinkan GitHub Actions bila diminta.
3. Jalankan workflow **Build APK** atau tunggu workflow berjalan setelah commit.
4. Buka hasil workflow yang selesai, lalu unduh artifact `KasirNominal-debug-apk`.
5. Ekstrak artifact dan pasang `app-debug.apk` di HP. Android mungkin meminta izin memasang aplikasi dari sumber tersebut.

## Memakai printer
1. Nyalakan printer dan lakukan pairing dari Pengaturan Bluetooth Android.
2. Saat mencetak, pilih printer dari daftar perangkat yang sudah dipasangkan.
3. Printer harus mendukung Bluetooth Classic SPP (UUID serial port) dan ESC/POS. Printer yang hanya memakai Bluetooth BLE mungkin tidak kompatibel.

## Catatan penting
- Ini masih versi awal yang perlu diuji pada HP dan printer sebenarnya sebelum dipakai untuk operasional harian.
- Data transaksi tersimpan lokal. Jangan hapus data aplikasi atau uninstall sebelum menyalin cadangan.
- Cadangan CSV versi ini disimpan di folder eksternal khusus aplikasi; mekanisme impor/pemulihan belum tersedia.
- Laporan saat ini hanya menampilkan hari ini. Pemilihan tanggal, riwayat transaksi detail, dan cetak ulang transaksi lama belum tersedia.
- Izin Bluetooth dan kompatibilitas printer dapat berbeda menurut versi Android dan model printer.
- APK debug cocok untuk uji coba, belum merupakan rilis produksi bertanda tangan.
