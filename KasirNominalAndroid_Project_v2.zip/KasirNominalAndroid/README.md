# Kasir Nominal — proyek Android awal

Fitur yang direncanakan pada proyek ini:
- Tombol angka 0–9, 00, 000, tambah (+), pengurang (−), hapus, dan sama dengan (=).
- Nominal masuk ke daftar vertikal seperti nota.
- Simpan transaksi ke database SQLite lokal di HP.
- Laporan omzet dan jumlah transaksi harian.
- Cetak struk melalui printer thermal Bluetooth 58 mm yang mendukung Bluetooth Classic SPP dan ESC/POS.
- Dapat berjalan offline setelah dipasang.

## Build APK tanpa laptop (GitHub Actions)
1. Buat akun GitHub di https://github.com/signup melalui HP.
2. Buat repository baru, misalnya `kasir-nominal`.
3. Unggah seluruh isi folder proyek `KasirNominalAndroid` ke repository (bukan file ZIP-nya saja).
4. Buka tab **Actions**. Jika diminta, izinkan Actions berjalan.
5. Jalankan workflow **Build APK** (atau tunggu otomatis berjalan setelah push).
6. Setelah selesai, buka hasil workflow dan unduh artifact **KasirNominal-debug-apk**.
7. Ekstrak ZIP artifact, lalu instal `app-debug.apk` di HP. Android mungkin meminta izin instal aplikasi dari sumber tersebut.

## Memakai printer
1. Pairing printer dari Pengaturan Bluetooth Android terlebih dahulu.
2. Printer dipilih dari daftar perangkat yang sudah dipasangkan saat mencetak.
3. Printer harus mendukung Bluetooth Classic SPP dan perintah ESC/POS. Printer BLE-only mungkin tidak kompatibel.

## Catatan penting
- Ini masih proyek sumber awal, **belum menjadi APK dan belum diuji pada HP/printer sebenarnya**.
- Data transaksi disimpan lokal di database aplikasi. Jangan hapus data aplikasi atau uninstall sebelum ada mekanisme pemulihan cadangan yang teruji.
- Fitur backup pada versi awal membuat file CSV di folder penyimpanan aplikasi; pemulihan/import cadangan belum dibuat.
- Pemilihan tanggal laporan, daftar transaksi lama yang bisa dibuka ulang, dan reprint struk historis masih perlu disempurnakan sebelum aplikasi layak dipakai untuk operasional penuh.
- Izin Bluetooth Android versi baru dan kompatibilitas printer perlu diuji pada perangkat sebenarnya.
