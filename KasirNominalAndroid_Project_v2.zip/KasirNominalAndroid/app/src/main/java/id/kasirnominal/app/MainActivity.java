package id.kasirnominal.app;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    TextView display, totalView, linesView;
    String entry = "0";
    ArrayList<Long> current = new ArrayList<>();
    LinearLayout root, content;
    String tab = "kasir";
    static final Locale ID = new Locale("id","ID");

    String money(long n) { return "Rp" + NumberFormat.getIntegerInstance(ID).format(Math.abs(n)); }
    long total() { long s=0; for(long n:current)s+=n; return s; }
    int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        db = new DB(this);
        showKasir();
    }

    TextView text(String s, int size, boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(0xff17211b); if(bold)t.setTypeface(null,Typeface.BOLD);
        t.setPadding(dp(5),dp(7),dp(5),dp(7)); return t;
    }
    Button button(String s, Runnable r) {
        Button b=new Button(this); b.setText(s); b.setAllCaps(false);
        b.setOnClickListener(v->r.run()); return b;
    }
    LinearLayout vertical() { LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(dp(12),dp(8),dp(12),dp(8)); return l; }
    void base(String title) {
        root=vertical(); root.setBackgroundColor(0xfff3f6f4);
        TextView h=text(title,22,true); h.setTextColor(0xffffffff); h.setBackgroundColor(0xff14532d); h.setPadding(dp(16),dp(18),dp(16),dp(18));
        root.addView(h); setContentView(root);
        LinearLayout nav=new LinearLayout(this);
        nav.addView(button("Kasir",()->showKasir()),new LinearLayout.LayoutParams(0,dp(48),1));
        nav.addView(button("Laporan",()->showReport()),new LinearLayout.LayoutParams(0,dp(48),1));
        root.addView(nav);
        ScrollView sc=new ScrollView(this); content=vertical(); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    }
    void addFull(View v) { content.addView(v,new LinearLayout.LayoutParams(-1,-2)); }
    void digit(String d) { entry=(entry.equals("0")?d:entry+d); if(entry.length()>13)entry=entry.substring(0,13); refresh(); }
    void addLine(long sign) {
        long n; try{n=Long.parseLong(entry);}catch(Exception e){n=0;}
        if(n>0)current.add(n*sign); entry="0"; refresh();
    }
    void refresh() {
        if(display!=null)display.setText(money(parseEntry()));
        if(totalView!=null)totalView.setText("TOTAL  "+(total()<0?"-":"")+money(total()));
        if(linesView!=null) {
            StringBuilder s=new StringBuilder();
            for(int i=0;i<current.size();i++) s.append(i+1).append(". ").append(current.get(i)<0?"Pengurang  -":"Nominal  ").append(money(current.get(i))).append("\n");
            if(current.size()==0)s.append("Belum ada nominal.");
            linesView.setText(s.toString());
        }
    }
    long parseEntry(){try{return Long.parseLong(entry);}catch(Exception e){return 0;}}
    void showKasir() {
        tab="kasir"; base("KASIR NOMINAL");
        addFull(text("NOMINAL",12,true));
        display=text(money(parseEntry()),30,true); display.setGravity(Gravity.RIGHT); addFull(display);
        GridLayout grid=new GridLayout(this); grid.setColumnCount(4);
        String[] keys={"7","8","9","+","4","5","6","−","1","2","3","⌫","00","0","000","="};
        for(String k:keys){
            Button b=button(k,()->{
                if(k.matches("[0-9]+")) digit(k);
                else if(k.equals("+")||k.equals("=")) addLine(1);
                else if(k.equals("−")) addLine(-1);
                else if(k.equals("C")){entry="0";refresh();}
                else if(k.equals("⌫")){entry=entry.length()>1?entry.substring(0,entry.length()-1):"0";refresh();}
            });
            GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0;p.height=dp(58);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(dp(3),dp(3),dp(3),dp(3));grid.addView(b,p);
        }
        addFull(grid);
        totalView=text("TOTAL  "+money(total()),22,true); addFull(totalView);
        linesView=text("",15,false); addFull(linesView);
        addFull(button("Batalkan baris terakhir",()->{if(!current.isEmpty())current.remove(current.size()-1);refresh();}));
        addFull(button("Kosongkan transaksi",()->{current.clear();entry="0";refresh();}));
        addFull(button("SIMPAN TRANSAKSI & CETAK STRUK",()->saveAndPrint()));
        refresh();
    }
    void saveAndPrint() {
        if(current.isEmpty()){toast("Masukkan nominal terlebih dahulu");return;}
        long sum=total(); if(sum<0){toast("Total tidak boleh negatif");return;}
        long id=db.insert(current,sum);
        ArrayList<Long> copy=new ArrayList<>(current);
        current.clear();entry="0";refresh();
        printReceipt(id,copy,sum);
        toast("Transaksi tersimpan");
    }
    void showReport() {
        tab="laporan"; base("LAPORAN HARIAN");
        String date=new SimpleDateFormat("yyyy-MM-dd",ID).format(new Date());
        TextView summary=text("",18,true); addFull(summary);
        LinearLayout list=vertical(); addFull(list);
        Runnable render=()->{
            Cursor c=db.day(date); long sum=0;int count=0;StringBuilder s=new StringBuilder();
            while(c.moveToNext()){count++;long id=c.getLong(0),amount=c.getLong(1);sum+=amount;s.append("Transaksi ").append(count).append("   ").append(money(amount)).append("\n");}
            c.close();summary.setText("Tanggal: "+date+"\nJumlah transaksi: "+count+"\nTOTAL OMZET: "+money(sum));
            list.removeAllViews();list.addView(text(s.length()==0?"Belum ada transaksi.":s.toString(),15,false));
            list.addView(button("CETAK LAPORAN",()->printReport(date)));
        };
        addFull(button("Muat ulang laporan hari ini",render)); render.run();
        addFull(button("Cadangkan data ke file",()->backup()));
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    void ensureBluetoothPermission() {
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},44);
    }
    void choosePrinter(byte[] data) {
        ensureBluetoothPermission();
        try {
            BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
            if(adapter==null){toast("HP tidak mendukung Bluetooth");return;}
            if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){toast("Izinkan akses perangkat Bluetooth lalu tekan cetak lagi");return;}
            Set<BluetoothDevice> paired=adapter.getBondedDevices();
            ArrayList<BluetoothDevice> devices=new ArrayList<>(paired);
            if(devices.isEmpty()){toast("Pairing printer dari Pengaturan Bluetooth HP terlebih dahulu");return;}
            String[] names=new String[devices.size()];
            for(int i=0;i<devices.size();i++)names[i]=devices.get(i).getName()+" ("+devices.get(i).getAddress()+")";
            new AlertDialog.Builder(this).setTitle("Pilih printer 58 mm").setItems(names,(d,which)->new Thread(()->{
                try{
                    BluetoothDevice dev=devices.get(which);
                    BluetoothSocket socket=dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
                    socket.connect();OutputStream out=socket.getOutputStream();out.write(data);out.flush();out.close();socket.close();
                    runOnUiThread(()->toast("Perintah cetak dikirim"));
                }catch(Exception e){runOnUiThread(()->toast("Gagal mencetak. Pastikan printer menyala dan sudah dipasangkan."));}
            }).start()).setNegativeButton("Batal",null).show();
        }catch(SecurityException e){toast("Izin Bluetooth belum diberikan");}
    }
    byte[] escpos(String body) throws Exception {
        ByteArrayOutputStream o=new ByteArrayOutputStream();
        o.write(new byte[]{0x1b,0x40}); // initialize
        o.write(new byte[]{0x1b,0x61,0x01}); o.write("STRUK PENJUALAN\nKASIR NOMINAL\n".getBytes("CP437"));
        o.write(new byte[]{0x1b,0x61,0x00}); o.write("--------------------------------\n".getBytes("CP437"));
        o.write(body.getBytes("CP437"));o.write("--------------------------------\n".getBytes("CP437"));
        o.write(new byte[]{0x1b,0x45,0x01});o.write(("TOTAL  "+body.substring(body.lastIndexOf("TOTAL  ")+7)+"\n").getBytes("CP437"));o.write(new byte[]{0x1b,0x45,0x00});
        o.write("\nTerima kasih\n\n\n".getBytes("CP437"));o.write(new byte[]{0x1d,0x56,0x41,0x10});return o.toByteArray();
    }
    void printReceipt(long id,ArrayList<Long> lines,long sum) {
        StringBuilder b=new StringBuilder("No: ").append(id).append("\n").append(new SimpleDateFormat("dd-MM-yyyy HH:mm",ID).format(new Date())).append("\n");
        for(int i=0;i<lines.size();i++)b.append(i+1).append(". ").append(lines.get(i)<0?"-":"").append(money(lines.get(i))).append("\n");
        b.append("TOTAL  ").append(money(sum)).append("\n");
        try{choosePrinter(escpos(b.toString()));}catch(Exception e){toast("Gagal menyiapkan struk");}
    }
    void printReport(String date) {
        Cursor c=db.day(date);StringBuilder b=new StringBuilder("Tanggal: ").append(date).append("\n");long sum=0;int i=0;
        while(c.moveToNext()){i++;long n=c.getLong(1);sum+=n;b.append(i).append(". ").append(money(n)).append("\n");}c.close();
        b.append("Jumlah transaksi: ").append(i).append("\nTOTAL  ").append(money(sum)).append("\n");
        try{choosePrinter(escpos(b.toString()));}catch(Exception e){toast("Gagal menyiapkan laporan");}
    }
    void backup(){
        try{
            File f=new File(getExternalFilesDir(null),"kasir-nominal-backup.csv");
            Cursor c=db.all();FileWriter w=new FileWriter(f);w.write("id,tanggal,total,nominal\n");
            while(c.moveToNext())w.write(c.getLong(0)+","+c.getString(1)+","+c.getLong(2)+","+c.getString(3)+"\n");
            c.close();w.close();toast("Cadangan dibuat: "+f.getAbsolutePath());
        }catch(Exception e){toast("Gagal membuat cadangan");}
    }
    static class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"kasir_nominal.db",null,1);}
        public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE tx(id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT, day TEXT, total INTEGER, lines TEXT)");}
        public void onUpgrade(SQLiteDatabase d,int a,int b){}
        long insert(ArrayList<Long> lines,long total){
            StringBuilder s=new StringBuilder();for(long n:lines){if(s.length()>0)s.append("|");s.append(n);}
            ContentValues v=new ContentValues();String now=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",ID).format(new Date());
            v.put("created",now);v.put("day",now.substring(0,10));v.put("total",total);v.put("lines",s.toString());
            return getWritableDatabase().insert("tx",null,v);
        }
        Cursor day(String day){return getReadableDatabase().rawQuery("SELECT id,total FROM tx WHERE day=? ORDER BY id",new String[]{day});}
        Cursor all(){return getReadableDatabase().rawQuery("SELECT id,day,total,lines FROM tx ORDER BY id",null);}
    }
}
